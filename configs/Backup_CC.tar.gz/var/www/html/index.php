<?php
session_start();

require_once "functions.php";
require_once "router.php";
