<?php 

$tabname = "ComplianceCheck";
$pos = "max-w-7xl";
require "views/headers/landingView.php";
