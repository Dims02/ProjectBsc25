<?php

$heading = "Contact Us";
$tabname = "Contact Us";
$bgcolor = "bg-gray-100";
$pos = "max-w-4xl";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name    = $_POST['name']    ?? '';
    $email   = $_POST['email']   ?? '';
    $message = $_POST['message'] ?? '';

    if (!$name || !$email || !$message) {
        $_SESSION['error_message'] = 'All fields are required.';
    } else {
        //todo save msg
        $_SESSION['success_message'] = 'Message sent successfully.';
        header('Location: /contacts');
        exit;
    }
}

require "views/headers/contactsView.php";
