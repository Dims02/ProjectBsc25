<?php

$heading = "About Us";
$tabname = "About Us";
$bgcolor = "bg-gray-100";
$pos = "max-w-7xl";

require "views/headers/aboutView.php"; 

