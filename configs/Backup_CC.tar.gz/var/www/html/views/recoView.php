<?php require "partials/header.php"; ?>
<?php require "partials/nav.php"; ?>
<?php require "partials/banner.php"; ?>

  <div class="max-w-6xl mx-auto space-y-8">
    
    <!-- Export Buttons -->
    <div class="flex flex-wrap justify-end gap-4 mt-5">
      <a
        href="export?survey_id=<?= htmlspecialchars(encodeSurveyId($survey_id), ENT_QUOTES, 'UTF-8') ?>&type=json"
        class="inline-flex items-center space-x-2 bg-indigo-600 hover:bg-indigo-500 text-white font-medium py-2 px-4 rounded-lg shadow"
      >
        <svg class="h-5 w-5" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
          <path d="M4 4v16h16V4H4zm8 1v10m0 0l-3-3m3 3l3-3"/>
        </svg>
        <span>Export JSON</span>
      </a>
      <a
        href="export?survey_id=<?= htmlspecialchars(encodeSurveyId($survey_id), ENT_QUOTES, 'UTF-8') ?>&type=pdf"
        class="inline-flex items-center space-x-2 bg-indigo-600 hover:bg-indigo-500 text-white font-medium py-2 px-4 rounded-lg shadow"
      >
        <svg class="h-5 w-5" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
        <path d="M4 4v16h16V4H4zm8 1v10m0 0l-3-3m3 3l3-3"/>
        </svg>
        <span>Export PDF</span>
      </a>
    </div>

    <?php if (!empty($groupedIncorrect)): ?>
      <?php foreach ($groupedIncorrect as $group): ?>
        <div class="bg-white shadow-lg rounded-lg overflow-hidden">
          <!-- Group Header -->
          <div class="px-6 py-4 bg-gradient-to-r from-indigo-500 to-purple-500">
            <h2 class="text-xl font-semibold text-white">
              <?= htmlspecialchars($group['group_title'], ENT_QUOTES, 'UTF-8') ?>
            </h2>
          </div>
          <div class="p-6 space-y-6">
            <?php if (!empty($group['group_recommendation'])): ?>
              <div class="text-indigo-600 italic">
                <?= htmlspecialchars(strip_tags($group['group_recommendation']), ENT_QUOTES, 'UTF-8') ?>
              </div>
            <?php endif; ?>

            <?php foreach ($group['questions'] as $item): ?>
              <div class="border-l-4 border-indigo-500 pl-4 space-y-1">
                <h3 class="text-lg font-medium text-gray-800">
                  Question: <?= htmlspecialchars(strip_tags($item['question']), ENT_QUOTES, 'UTF-8') ?>
                </h3>
                <p class="text-gray-700">
                  <strong>Your Answer:</strong>
                  <?= htmlspecialchars(strip_tags($item['your_answer']), ENT_QUOTES, 'UTF-8') ?>
                </p>
                <p class="text-indigo-600">
                  <strong>Recommendation:</strong>
                  <?= htmlspecialchars(strip_tags($item['recommendation']), ENT_QUOTES, 'UTF-8') ?>
                </p>
              </div>
            <?php endforeach; ?>
          </div>
        </div>
      <?php endforeach; ?>
    <?php else: ?>
      <div class="bg-green-100 border border-green-200 text-green-800 px-6 py-4 rounded-lg shadow text-center">
        <p class="font-medium">🎉 Congratulations! All your answers are correct.</p>
      </div>
    <?php endif; ?>

  </div>
<div class="pb-8"></div>
<?php require "partials/footer.php"; ?>
