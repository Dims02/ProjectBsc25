<?php
// Disable any output buffering or session-related output
if (session_status() === PHP_SESSION_ACTIVE) {
    session_write_close();
}

// Absolute path to the image
$imagePath = __DIR__ . '/logos_ccc.png';


// Clean output buffer if anything was started
if (ob_get_level()) {
    ob_end_clean();
}

// Send proper headers
header('Content-Type: image/png');
header('Content-Length: ' . filesize($imagePath));
header('Cache-Control: public, max-age=86400');

// Send image
readfile($imagePath);
exit;
?>
