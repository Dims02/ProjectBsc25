
</main>
<footer class="bg-gray-900 text-white py-2  left-0 w-full">
  <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
    <div class="flex flex-col md:flex-row justify-between items-center">
      <p class="text-sm text-gray-400">&copy; 2025 ComplianceCheck. All rights reserved.</p>
	  <p class="text-sm text-gray-400">&copy; Diogo Silva UBI</p>
      <div class="flex space-x-6 mt-4 md:mt-0">
        <a href="/contacts" class="text-gray-400 hover:text-white text-sm">Contact Us</a>
      </div>
    </div>
  </div>
</footer>
