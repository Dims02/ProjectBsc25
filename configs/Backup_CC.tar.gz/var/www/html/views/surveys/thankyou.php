<?php 
$heading = "Thank You";
$tabname = "Survey";
$bgcolor = "bg-gradient-to-br from-indigo-50 to-indigo-100";
?>
<?php require_once __DIR__ . '/../partials/header.php'; ?>
<?php require_once __DIR__ . '/../partials/nav.php'; ?>

  <div class="bg-white max-w-lg mx-auto text-center rounded-2xl shadow-lg p-8 space-y-6 mt-40">
    <!-- Success Icon -->
    <svg class="mx-auto h-16 w-16 text-green-500" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
      <path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7" />
    </svg>

    <h2 class="text-3xl font-extrabold text-gray-900">
      Submission Successful
    </h2>

    <p class="text-gray-600">
      Thank you for completing the survey.
      You can view all results on the bottom of the dashboard page.
    </p>  

    <a
      href="/dashboard"
      class="inline-block bg-indigo-600 hover:bg-indigo-500 text-white font-semibold py-3 px-8 rounded-lg transition-shadow shadow-md hover:shadow-lg"
    >
      Return to Dashboard
    </a>
  </div>

<?php require_once __DIR__ . '/../partials/footer.php'; ?>
